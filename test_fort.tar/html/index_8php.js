var index_8php =
[
    [ "$connect", "index_8php.html#a956617395b85e98d907df712f6d0d3f7", null ],
    [ "$db", "index_8php.html#a1fa3127fc82f96b1436d871ef02be319", null ],
    [ "$query", "index_8php.html#add61449c6e54addeb29711a9f99c6802", null ]
];