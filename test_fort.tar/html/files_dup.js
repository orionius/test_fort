var files_dup =
[
    [ "connect.php", "connect_8php.html", [
      [ "Con", "class_con.html", "class_con" ]
    ] ],
    [ "index.php", "index_8php.html", "index_8php" ]
];