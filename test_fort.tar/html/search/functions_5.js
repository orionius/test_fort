var searchData=
[
  ['gotourl_23',['gotoUrl',['../a00028.html#ae5cc9175d3d27756329b1fb6db1e06f7',1,'SecondInterface\gotoUrl()'],['../a00032.html#ae5cc9175d3d27756329b1fb6db1e06f7',1,'Func\gotoUrl()']]]
];
