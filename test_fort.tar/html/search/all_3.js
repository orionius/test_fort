var searchData=
[
  ['delete_5',['delete',['../a00020.html#a2f8258add505482d7f00ea26493a5723',1,'FirstInterface\delete()'],['../a00024.html#a2f8258add505482d7f00ea26493a5723',1,'Con\delete()']]]
];
