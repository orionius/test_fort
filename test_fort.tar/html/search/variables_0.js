var searchData=
[
  ['_24connect_16',['$connect',['../index_8php.html#a956617395b85e98d907df712f6d0d3f7',1,'index.php']]],
  ['_24db_17',['$db',['../index_8php.html#a1fa3127fc82f96b1436d871ef02be319',1,'index.php']]],
  ['_24query_18',['$query',['../index_8php.html#add61449c6e54addeb29711a9f99c6802',1,'index.php']]]
];
