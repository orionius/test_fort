var searchData=
[
  ['database_19',['DATABASE',['../class_con.html#a671e180a0a9486e82d3f3ccb1f4761f6',1,'Con']]]
];
