var indexSectionsWithContent =
{
  0: "abcdefgs",
  1: "cfs",
  2: "abdefg"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions"
};

var indexSectionLabels =
{
  0: "Указатель",
  1: "Структуры данных",
  2: "Функции"
};

